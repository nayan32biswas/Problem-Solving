#include <bits/stdc++.h>
using namespace std;
#define fix(n) setw(n) << fixed << setprecision(2)
#define sec second
class MEAL
{
  private:
    struct data
    {
        string name;
        double bought, meal, person, pay;
        bool takeWater;
    };
    struct EachPerson
    {
        double bazar, meal, mealCost, khala, waste, water, cost, balance, paid;
    };
    vector<data> List;
    map<string, EachPerson> eachPerson;
    double totalBazar, totalMeal, totalMealCost, totalKhalaBill, totalCost, totalPerson, totalBalance, totalPaid;
    double khalaBillRate, totalWaste, totalWaterBill;
    double mealRate, waterRate, wasteRate;
    double takeWaterPersonMeal;

  public:
    int x;
    void input()
    {
        cin >> khalaBillRate >> totalWaste >> totalWaterBill;
        data temp;
        while (cin >> temp.name >> temp.bought >> temp.meal >> temp.person >> temp.takeWater >> temp.pay)
        {
            List.push_back(temp);
        }
    }
    void calculate()
    {
        totalBazar = totalMeal = totalPerson = takeWaterPersonMeal = 0;
        for (auto it : List)
        {
            totalBazar += it.bought;
            totalMeal += it.meal;
            totalPerson += it.person;
            if (it.takeWater)
            {
                takeWaterPersonMeal += it.meal;
            }
        }
        mealRate = (totalBazar / totalMeal);
        waterRate = (totalWaterBill / takeWaterPersonMeal);
        wasteRate = (totalWaste / totalPerson);
        totalKhalaBill = totalMealCost = totalCost = totalBalance = totalPaid = 0;
        for (auto it : List)
        {
            eachPerson[it.name].meal = it.meal;
            eachPerson[it.name].bazar = it.bought;
            eachPerson[it.name].paid = it.pay;
            eachPerson[it.name].mealCost = it.meal * mealRate;
            eachPerson[it.name].khala = it.person * khalaBillRate;
            eachPerson[it.name].waste = it.person * wasteRate;
            eachPerson[it.name].water = it.takeWater * it.meal * waterRate;

            eachPerson[it.name].cost = (eachPerson[it.name].mealCost + eachPerson[it.name].khala + eachPerson[it.name].waste + eachPerson[it.name].water);
            eachPerson[it.name].balance = eachPerson[it.name].bazar - eachPerson[it.name].cost + eachPerson[it.name].paid;

            totalBalance += eachPerson[it.name].balance;
            totalMealCost += eachPerson[it.name].mealCost;
            totalCost += eachPerson[it.name].cost;
            totalKhalaBill += eachPerson[it.name].khala;
            totalPaid += eachPerson[it.name].paid;
        }
    }
    void show()
    {
        //puts("      Name         Bazar       Meal      Meal cost      khala      water       waste      Cost       Balance\n");
        int n = 12, start = 7;
        cout << setw(start) << "Name" << setw(n) << "Buzar" << setw(n) << "Meal" << setw(n) << "MealCost" << setw(n) << "Khala";
        cout << setw(n) << "water" << setw(n) << "Waste" << setw(n) << "TotalCost" << setw(n) << "Balance" << setw(n) << "Paid" << endl
             << endl;
        for (auto it : eachPerson)
        {
            cout << setw(start) << it.first << fix(n) << it.sec.bazar << fix(n) << it.sec.meal << fix(n) << it.sec.mealCost << fix(n) << it.sec.khala;
            cout << fix(n) << it.sec.water << fix(n) << it.sec.waste << fix(n) << it.sec.cost << fix(n) << round(it.sec.balance) << fix(n) << it.sec.paid << endl
                 << endl;
        }
        //puts("Total    bazar        Meal        Person    Khala Bill    Payable");
        cout << setw(start) << "Total" << fix(n) << totalBazar << fix(n) << totalMeal << fix(n) << totalMealCost << fix(n) << totalKhalaBill;
        cout << fix(n) << totalWaterBill << fix(n) << totalWaste << fix(n) << totalCost << fix(n) << totalBalance << fix(n) << totalPaid << endl
             << endl;
        //puts("Rate    Meal        Water      Waste");
        cout << setw(start) << "Rate" << setw(n) << "Meal" << setw(n) << "Water" << setw(n) << "Waste" << endl;
        cout << setw(start) << "" << fix(n) << mealRate << fix(n) << waterRate << fix(n) << wasteRate << endl;
    }
};
int main()
{
    freopen("201903.txt", "r", stdin);
    MEAL meal;
    meal.input();
    meal.calculate();
    meal.show();
}
