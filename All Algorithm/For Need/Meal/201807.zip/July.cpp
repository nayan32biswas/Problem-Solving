#include <bits/stdc++.h>
using namespace std;
#define fix(n) fixed<<setprecision(n)
double meal, sum, bazar, temp;
double meal_rate, water_rate, waste;
int water_unit, total, unit, paid;
string name;
int main() {
    freopen("july.txt", "r", stdin);
    puts("    Name Bazar        Meal          khala      waste         water            Total\n");
    cin>>meal_rate>>water_rate>>waste;
    while(cin>>name>>total>>meal>>unit>>water_unit>>paid) {
        cout<<setw(8)<<name<<setw(5)<<total<<" - ( ("<<setw(6)<<fix(2)<<meal<<"*"<<fix(2)<<(meal_rate)<<") + (350*"<<unit<<") + ("<<unit<<"*"<<waste<<") + ("<<fix(3)<<water_rate<<"*"<<setw(5)<<fix(2)<<meal<<"*"<<water_unit<<") ) = ";
        temp = total-((meal_rate*meal) + ((unit*350)+(waste*unit)) + (water_rate*water_unit*meal));
        cout<<setw(5)<<fix(2)<<round(temp)+paid<<endl<<endl;
        sum += temp+paid;
        bazar+=total;
    }
    cout<<"total bazar = "<<bazar<<endl;
    cout<<"Payable = "<<sum<<endl;
}
