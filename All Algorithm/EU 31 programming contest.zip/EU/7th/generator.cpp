#include <bits/stdc++.h>
using namespace std;
long long int Find(long long int n){
    return random()%n+1;
}
int main()
{
    srand(time(NULL));
    freopen("input.txt", "w", stdout);
    int n, m;
    cin>>n>>m;
    cout<<n<<endl;
    cout<<m<<endl;
    for(int i=0; i<m; i++){
        long long A = Find(n);
        long long B = Find(n);
        cout<<min(A, B)<<" "<<max(A, B)<<endl;
    }
    return 0;
}