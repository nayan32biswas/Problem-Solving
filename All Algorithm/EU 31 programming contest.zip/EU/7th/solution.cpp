#include <bits/stdc++.h>
using namespace std;
#define Size 1000005
int markRange[Size];
void rangeRun()
{
    for (int i = 1; i < Size; i++)
        markRange[i] += markRange[i - 1];
}
void rangeMark(int lo, int hi)
{
    lo = max(0, lo - 1); /// one base
    hi = min(Size - 2, hi);
    markRange[lo]++;
    markRange[hi]--;
}
void rangeMax()
{
    int Max = 0, point;
    for (int i = 0; i < Size; i++)
    {
        if(Max<markRange[i]){
            Max = markRange[i];
            point = i+1;
        }
    }
    printf("%d %d\n", point, Max);
}
int main()
{
    // long long time = clock();
    
    // freopen("input5.txt", "r", stdin);
    // freopen("output5.txt", "w", stdout);
    int m, n, a, b;
    memset(markRange, 0, sizeof(markRange));
    scanf("%d", &m);
    scanf("%d", &n);
    for(int i=0; i<n; i++){
        scanf("%d%d", &a, &b);
        rangeMark(a, b);
    }
    rangeRun();

    rangeMax();
    // cout<<(clock()-time)/10000<<endl;
    return 0;
}